module.exports.URI = "mongodb+srv://contactlistserver:L@pitan090819@mongodbserver.jmapd.mongodb.net/survey";
//module.exports.URI = "mongodb://localhost:27017/UrWay";