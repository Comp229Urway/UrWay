module.exports.URI = "mongodb+srv://TLB2310:tlb2310@cluster0.ldslt.mongodb.net/UrWay?retryWrites=true&w=majority";
//module.exports.URI = "mongodb://localhost:27017/UrWay";